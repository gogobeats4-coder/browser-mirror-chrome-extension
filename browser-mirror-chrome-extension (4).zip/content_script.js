(async () => {
  const { BroadcastingRunner } =
    /** @type {typeof import('./lib/broadcasting_runner.js')} */ (
      await import(chrome.runtime.getURL('./lib/broadcasting_runner.js'))
    );
  const { MirroringRunner } =
    /** @type {typeof import('./lib/mirroring_runner.js')} */ (
      await import(chrome.runtime.getURL('./lib/mirroring_runner.js'))
    );
  window.broadcastingRunner = new BroadcastingRunner();
  window.mirroringRunner = new MirroringRunner();
  window.tabState = 'Idle';
  window.addEventListener('beforeunload', () => {
    window.broadcastingRunner?.stop();
    window.mirroringRunner?.stop();
  });
})();
