import { desktopApi } from '../../lib/desktop_api.js';
import { getBrowserState, resetBrowserState } from '../../lib/state.js';

/**
 * @param {chrome.webNavigation.WebNavigationTransitionCallbackDetails} details
 */
export async function onCommitted(details) {
  const { tabId, frameId, transitionQualifiers, transitionType, url } = details;
  if (frameId !== 0) return;
  const browserState = await getBrowserState();
  if (browserState?.tabId !== tabId) return;

  let error = null;

  if (browserState.type === 'Broadcasting') {
    if (
      transitionQualifiers.includes('forward_back') ||
      transitionQualifiers.includes('from_address_bar') ||
      transitionType === 'reload'
    ) {
      /** @type {RecordedEvent?} */
      let event = null;

      if (transitionQualifiers.includes('forward_back')) {
        const pressedForward = (
          await chrome.scripting.executeScript({
            target: { tabId, frameIds: [frameId] },
            func:
              /** @returns {Promise<boolean>} */
              async () => {
                return window.confirm(
                  'Press Cancel if you pressed Back button, press OK if you pressed Forward'
                );
              },
            injectImmediately: true,
          })
        )[0].result;

        event = {
          type: 'navigate',
          navigation: pressedForward ? { forward: true } : { back: true },
        };
      } else {
        event = transitionQualifiers.includes('from_address_bar')
          ? { type: 'navigate', navigation: { url } }
          : { type: 'reloadTab' };
      }

      try {
        const res = await desktopApi.broadcast({
          operation: 'broadcast',
          recordedEvent: { ...event },
        });

        if (!res.ok) {
          error = `Desktop app gave HTTP Error Code ${res.status}. Broadcasting stopped.`;
        }
      } catch {
        error =
          'Cannot not connect to the desktop app. Check if desktop app is running. Broadcasting stopped.';
      }
    }
  }

  const result = await chrome.scripting.executeScript({
    target: { tabId, frameIds: [frameId] },
    func:
      /**
       * @param {'Broadcasting' | 'Mirroring'} operation
       * @param {string?} error
       * @returns {Promise<boolean>}
       */
      async (operation, error) => {
        if (error !== null) {
          alert(`Error: ${error}`);
          return false;
        }

        for (let i = 1; window.tabState === undefined && i <= 5; ++i) {
          await new Promise((r) => setTimeout(r, 100 * i));
        }

        if (window.tabState === undefined) {
          alert('Error: window.tabState === undefined');
          return false;
        }
        if (window.tabState !== 'Idle') {
          alert("Error: window.tabState !== 'Idle'");
          return false;
        }

        const runner =
          operation === 'Broadcasting'
            ? window.broadcastingRunner
            : window.mirroringRunner;

        if (runner === undefined) {
          alert('Error: runner === undefined');
          return false;
        }

        window.tabState = operation;
        await runner.continue();
        return true;
      },
    args: [browserState.type, error],
    injectImmediately: true,
  });
  if (result[0].result !== true) await resetBrowserState();
}
