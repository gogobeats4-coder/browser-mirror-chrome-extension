import { resetBrowserState, setBrowserState } from '../../../lib/state.js';

/**
 * @param {'Broadcasting' | 'Mirroring'} operation
 * @param {number} tabId
 * @param {BrowserState} browserState
 */
export async function start(operation, tabId, browserState) {
  const operationToLowerCase = operation.toLowerCase();

  if (browserState === null) {
    chrome.debugger.attach({ tabId: tabId }, '1.2', async () => {
      // NOTE: suppress "already attached" error
      chrome.runtime.lastError;
      try {
        await setBrowserState({ type: operation, tabId });
        const result = await chrome.scripting.executeScript({
          target: { tabId: tabId },
          func: async (operation) => {
            for (let i = 1; window.tabState === undefined && i <= 5; ++i) {
              await new Promise((r) => setTimeout(r, 100 * i));
            }

            if (window.tabState === undefined) {
              alert(
                'Error: window.tabState === undefined. Reload the tab and try again. Most likely this tab has not been reloaded after extension installation or reload, or extension has been turned off/on.'
              );
              return false;
            }
            if (window.tabState !== 'Idle') {
              alert("Error: window.tabState !== 'Idle'.");
              return false;
            }
            const runner =
              operation === 'Broadcasting'
                ? window.broadcastingRunner
                : window.mirroringRunner;
            if (!runner) return false;
            await runner.start();
            return true;
          },
          args: [operation],
          injectImmediately: true,
        });
        if (result[0].result !== true) throw Error();
      } catch {
        await resetBrowserState();
        const msg = `Error: Failed to start ${operationToLowerCase}.`;
        await chrome.scripting.executeScript({
          target: { tabId: tabId },
          func: (msg) => {
            alert(msg);
          },
          args: [msg],
          injectImmediately: true,
        });
      }
    });

    return;
  }

  const stateToLowerCase = browserState.type.toLowerCase();

  const msg =
    browserState.tabId === tabId
      ? `This tab is already ${stateToLowerCase}.`
      : `Error: Cannot start ${operationToLowerCase} from this tab, because there is already a ${stateToLowerCase} tab in this browser.`;

  await chrome.scripting.executeScript({
    target: { tabId: tabId },
    func: (msg) => {
      alert(msg);
    },
    args: [msg],
  });
}
