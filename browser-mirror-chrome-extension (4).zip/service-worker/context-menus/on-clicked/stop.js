import { resetBrowserState } from '../../../lib/state.js';

/**
 * @param {number} tabId
 * @param {boolean} showAlert
 */
export async function stop(tabId, showAlert = true) {
  const tabIds = [tabId];
  const windows = await chrome.windows.getAll();
  for (const window of windows) {
    if (!window.tabs) continue;
    for (const tab of window.tabs) {
      if (!tab.id) continue;
      if (tab.id === tabId) continue;
      tabIds.push(tab.id);
    }
  }
  await Promise.allSettled(
    tabIds.map((tabId) => {
      return chrome.scripting.executeScript({
        target: { tabId },
        func: () => {
          window.broadcastingRunner?.stop();
          window.mirroringRunner?.stop();
        },
        injectImmediately: true,
      });
    })
  );
  await resetBrowserState();
  if (showAlert) {
    await chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        alert('Done!');
      },
      injectImmediately: true,
    });
  }
}
