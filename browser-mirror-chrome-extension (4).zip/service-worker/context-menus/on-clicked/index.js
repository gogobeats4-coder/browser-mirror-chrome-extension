import { getBrowserState } from '../../../lib/state.js';
import { align } from './align.js';
import { start } from './start.js';
import { stop } from './stop.js';

/**
 * @param {chrome.contextMenus.OnClickData} info
 * @param {chrome.tabs.Tab | undefined} tab
 */
export async function onClicked(info, tab) {
  if (!tab || !tab.id) return;
  const { id: tabId, windowId } = tab;

  if (
    info.menuItemId === 'start_broadcasting' ||
    info.menuItemId === 'start_mirroring'
  ) {
    const operation =
      info.menuItemId === 'start_broadcasting' ? 'Broadcasting' : 'Mirroring';
    await stop(tabId, false);
    const _start =
      /** @param {chrome.webNavigation.WebNavigationTransitionCallbackDetails} details */
      async (details) => {
        if (details.transitionType !== 'reload') return;
        const browserState = await getBrowserState();
        await start(operation, tabId, browserState);
        chrome.webNavigation.onCommitted.removeListener(_start);
      };
    chrome.webNavigation.onCommitted.addListener(_start);
    return await chrome.tabs.reload(tabId);
  }

  if (info.menuItemId === 'stop') {
    return await stop(tabId);
  }

  if (info.menuItemId === 'align') {
    return await align(windowId, tabId);
  }

  throw Error('Invalid menuItemId.');
}
