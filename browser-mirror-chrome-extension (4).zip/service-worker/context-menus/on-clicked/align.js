import { desktopApi } from '../../../lib/desktop_api.js';

/**
 * @param {number} currentWindowId
 * @param {number} tabId
 */
export async function align(currentWindowId, tabId) {
  const { height, width } = await chrome.windows.get(currentWindowId, {
    populate: false,
  });
  if (!height || !width) return;

  let error = null;

  try {
    /** @type {RecordedEvent} */
    const event = { type: 'alignWindow', align: { height, width } };

    const res = await desktopApi.broadcast({
      operation: 'broadcast',
      recordedEvent: { ...event },
    });

    if (!res.ok) {
      error = `Desktop app gave HTTP Error Code ${res.status}. Failed to align windows.`;
    }
  } catch {
    error =
      'Cannot not connect to the desktop app. Check if desktop app is running. Failed to align windows.';
  }

  if (error !== null) {
    await chrome.scripting.executeScript({
      target: { tabId },
      func:
        /** @param {string} error */
        async (error) => {
          alert(`Error: ${error}`);
        },
      args: [error],
      injectImmediately: true,
    });
  }
}
