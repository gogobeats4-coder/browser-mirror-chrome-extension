import { CDPSession } from '../../lib/cdp/cdpsession.js';
import { Keyboard } from '../../lib/cdp/keyboard.js';
import { Mouse } from '../../lib/cdp/mouse.js';

/**
 * @param {RuntimeMessage} msg
 * @param {chrome.runtime.MessageSender} sender
 * @param {(response?: any) => void} _
 */
export async function onMessage(msg, sender, _) {
  if (!sender.tab || !sender.tab.id) return;
  const tabId = sender.tab.id;

  if (msg.operation === 'closeTab') {
    await chrome.tabs.remove(tabId);
    return;
  } else if (msg.operation === 'reloadTab') {
    await chrome.tabs.reload(tabId);
    return;
  } else if (msg.operation === 'navigate') {
    if (
      !msg.navigation ||
      (!msg.navigation.url && !msg.navigation.forward && !msg.navigation.back)
    ) {
      throw Error('Error: Invalid navigation data during navigation replay.');
    }
    if (msg.navigation.back) {
      await chrome.tabs.goBack(tabId);
    } else if (msg.navigation.forward) {
      await chrome.tabs.goForward(tabId);
    } else {
      await chrome.tabs.update(tabId, { url: msg.navigation.url });
    }
    return;
  }

  if (msg.operation === 'alignWindow') {
    if (!msg.align) {
      throw Error('Error: msg.align is undefined during alignWindow');
    }
    const { height, width } = msg.align;
    await chrome.windows.update(sender.tab.windowId, { height, width });
    return;
  }

  const client = new CDPSession(tabId);
  const keyboard = new Keyboard(client);
  const mouse = new Mouse(client, keyboard);

  if (msg.operation === 'mouseClick' && msg.coord) {
    mouse.click(msg.coord.x, msg.coord.y);
  } else if (msg.operation === 'mouseMove' && msg.coord) {
    mouse.move(msg.coord.x, msg.coord.y);
  } else if (msg.operation === 'pressKey' && msg.key) {
    if (!msg.keyModifiers) {
      await keyboard.press(msg.key);
    } else {
      /** @type {Record<string, string>} */
      const map = {
        ctrlKey: 'Control',
        metaKey: 'Meta',
        shiftKey: 'Shift',
        altKey: 'Alt',
      };
      const modifierKeys = [];
      for (const [key, value] of Object.entries(msg.keyModifiers)) {
        if (value) {
          if (!map[key])
            throw Error(
              'Error: Invalid modifier key during pressKey with keyModifiers.'
            );
          modifierKeys.push(map[key]);
        }
      }
      modifierKeys.forEach(async (key) => await keyboard.down(key));
      await keyboard.press(msg.key);
      modifierKeys.forEach(async (key) => await keyboard.up(key));
    }
  }
}
