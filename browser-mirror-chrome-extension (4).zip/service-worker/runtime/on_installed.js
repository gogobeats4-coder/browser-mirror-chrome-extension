export function onInstalled() {
  chrome.contextMenus.create(
    {
      title: 'Start Broadcasting from this tab',
      id: 'start_broadcasting',
      contexts: ['all'],
    },
    () => chrome.runtime.lastError
  );
  chrome.contextMenus.create(
    {
      title: 'Start Mirroring from this tab',
      id: 'start_mirroring',
      contexts: ['all'],
    },
    () => chrome.runtime.lastError
  );
  chrome.contextMenus.create(
    {
      title: 'Stop Broadcasting/Mirroring in this browser',
      id: 'stop',
      contexts: ['all'],
    },
    () => chrome.runtime.lastError
  );
  chrome.contextMenus.create(
    {
      title: 'Align windows',
      id: 'align',
      contexts: ['all'],
    },
    () => chrome.runtime.lastError
  );
}
