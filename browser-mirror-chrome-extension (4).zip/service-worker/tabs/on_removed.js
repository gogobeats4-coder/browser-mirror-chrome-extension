import { desktopApi } from '../../lib/desktop_api.js';
import { getBrowserState, resetBrowserState } from '../../lib/state.js';

/**
 * @param {number} tabId
 * @param {chrome.tabs.TabRemoveInfo} _
 */
export async function onRemoved(tabId, _) {
  if ((await getBrowserState())?.tabId !== tabId) return;

  await resetBrowserState();

  try {
    /** @type {RecordedEvent} */
    const event = { type: 'closeTab' };
    await desktopApi.broadcast({
      operation: 'broadcast',
      recordedEvent: { ...event },
    });
  } catch {}
}
