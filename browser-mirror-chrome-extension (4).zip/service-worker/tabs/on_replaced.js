import { getBrowserState, setBrowserState } from '../../lib/state.js';

/**
 * @param {number} addedTabId
 * @param {number} removedTabId
 */
export async function onReplaced(addedTabId, removedTabId) {
  const state = await getBrowserState();
  if (state?.tabId !== removedTabId) return;

  await setBrowserState({ ...state, tabId: addedTabId });
}
