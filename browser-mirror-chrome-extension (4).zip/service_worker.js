/// <reference path="../types/index.d.ts" />

import { onClicked } from './service-worker/context-menus/on-clicked/index.js';
import { onInstalled } from './service-worker/runtime/on_installed.js';
import { onMessage } from './service-worker/runtime/on_message.js';
import { onRemoved } from './service-worker/tabs/on_removed.js';
import { onReplaced } from './service-worker/tabs/on_replaced.js';
import { onCommitted } from './service-worker/web-navigation/on_committed.js';

chrome.runtime.onInstalled.addListener(onInstalled);

chrome.contextMenus.onClicked.addListener(onClicked);

chrome.webNavigation.onCommitted.addListener(onCommitted);

chrome.tabs.onReplaced.addListener(onReplaced);

chrome.tabs.onRemoved.addListener(onRemoved);

chrome.runtime.onMessage.addListener(onMessage);
